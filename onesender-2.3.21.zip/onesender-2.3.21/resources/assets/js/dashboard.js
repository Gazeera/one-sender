(function() {
    console.log('dashboard.js');


})();
